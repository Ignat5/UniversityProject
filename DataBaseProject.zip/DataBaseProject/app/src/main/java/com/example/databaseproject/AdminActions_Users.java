package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.List;
import java.util.Map;

public class AdminActions_Users extends AppCompatActivity {

    public static List<Map<String,String>> dataListOfUsers;
    public static List<Map<String,String>> dataListOfReservations;
    ListView LV_Users;
    ListView LV_Users_Reserve;
    SimpleAdapter SA;

    Integer userID = 0;

    String userPhone = "";
    EditText ET_userPhone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_actions__users);

        ET_userPhone = (EditText) findViewById(R.id.ET_Admin_Users_FindUserByUsername);

        LV_Users = (ListView) findViewById(R.id.LV_AdminActions_Users);
        ShowUsers(getCurrentFocus());
        LV_Users_Reserve = (ListView) findViewById(R.id.LV_AdminActions_Users_Reservations);

        LV_Users.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Map<String,String> user = dataListOfUsers.get((int)id);
                userID = Integer.parseInt(user.get("USER_ID"));
                ShowReservations(getCurrentFocus());
            }
        });
    }

    public void ShowUsers(View view) {
        getData GD = new getData();
        dataListOfUsers = GD.getData_Users();
        String[] fromwhere = {"USER_ID","USER_NAME","USER_PHONE"};
        int[] viewwhere = {R.id.TV_templateUsers_ID,R.id.TV_templateUsers_userName, R.id.TV_templateUsers_userPhone};
        SA = new SimpleAdapter(AdminActions_Users.this,dataListOfUsers,R.layout.template_users,fromwhere,viewwhere);
        LV_Users.setAdapter(SA);
    }

    public void ShowReservations(View view) {
        getData GD = new getData();
        dataListOfReservations = GD.getData_Reservations(userID);
        String[] fromwhere = {"USERNAME","FILMNAME","DATE","PRICE","ROW","PLACE"};
        int[] viewwhere = {R.id.TV_Reservation_userName,R.id.TV_Reservation_filmName,R.id.TV_Reservation_sessionDate,
                R.id.TV_Reservation_sessionPrice,R.id.TV_Reservation_ParkingRow,R.id.TV_Reservation_ParkingPlace};
        SA = new SimpleAdapter(AdminActions_Users.this,dataListOfReservations,R.layout.template_reservations,fromwhere,viewwhere);
        LV_Users_Reserve.setAdapter(SA);
    }

    public void ShowChosenUser (View view) {
        if (ET_userPhone.getText().length() != 0) {
            userPhone = ET_userPhone.getText().toString();
            getData GD = new getData();
            dataListOfUsers = GD.getData_ChosenUser(userPhone);
            String[] fromwhere = {"USER_ID", "USER_NAME", "USER_PHONE"};
            int[] viewwhere = {R.id.TV_templateUsers_ID, R.id.TV_templateUsers_userName, R.id.TV_templateUsers_userPhone};
            SA = new SimpleAdapter(AdminActions_Users.this, dataListOfUsers, R.layout.template_users, fromwhere, viewwhere);
            LV_Users.setAdapter(SA);
        }else {
            Toast toast = Toast.makeText(getApplicationContext(),"Fill 'user phone' field",Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void ShowAllUsers(View view) {
        ShowUsers(getCurrentFocus());
    }

}