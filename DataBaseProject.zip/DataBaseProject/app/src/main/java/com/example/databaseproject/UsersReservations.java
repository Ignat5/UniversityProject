package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Condition;

public class UsersReservations extends AppCompatActivity {

    public static String EXTRA_USERID = "USERID";

    Integer userID = 0;
    SimpleAdapter SA;
    ListView LV_Reservations;
    public static List<Map<String,String>> dataListOfReservations;

    Button button_yes,button_no;
    TextView TV_choice;

    Integer reservationID = 0;
    Integer sessionID = 0;
    String chosenRow = "",chosenPlace = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_reservations);


        TV_choice = (TextView) findViewById(R.id.TV_Cancel);
        button_yes = (Button) findViewById(R.id.BTN_delete_yes);
        button_no = (Button) findViewById(R.id.BTN_delete_no);

        userID = (Integer)getIntent().getExtras().get(EXTRA_USERID);

        LV_Reservations = (ListView) findViewById(R.id.LV_UsersReservations);
        ShowReservations(getCurrentFocus());


        LV_Reservations.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TV_choice.setVisibility(View.VISIBLE);
                button_yes.setVisibility(View.VISIBLE);
                button_no.setVisibility(View.VISIBLE);

                Map<String,String> reservation = dataListOfReservations.get((int)id);
                reservationID = Integer.parseInt(reservation.get("RESERVATION_ID"));
                sessionID = Integer.parseInt(reservation.get("SESSION_ID"));
                chosenRow = reservation.get("ROW");
                chosenPlace = reservation.get("PLACE");

            }
        });
    }

    public void ShowReservations(View view) {
        getData GD = new getData();
        dataListOfReservations = GD.getData_Reservations(userID);
        String[] fromwhere = {"USERNAME","FILMNAME","DATE","PRICE","ROW","PLACE"};
        int[] viewwhere = {R.id.TV_Reservation_userName,R.id.TV_Reservation_filmName,R.id.TV_Reservation_sessionDate,
                R.id.TV_Reservation_sessionPrice,R.id.TV_Reservation_ParkingRow,R.id.TV_Reservation_ParkingPlace};
        SA = new SimpleAdapter(UsersReservations.this,dataListOfReservations,R.layout.template_reservations,fromwhere,viewwhere);
        LV_Reservations.setAdapter(SA);
    }

    public void CancelReservation (View view) {
        Connection connection = ConnectionHelper.getConnection();
        try {
            PreparedStatement ps = connection.prepareStatement("DELETE FROM RESERVATIONS WHERE reservation_id=?");
            ps.setInt(1,reservationID);
            ps.executeUpdate();

            String sql = "UPDATE ParkingPlace SET PP_isReserved = 0 WHERE (PP_row=? AND PP_place = ?) AND PP_sessionId = ?";
            PreparedStatement pStatement_ReservePlace = connection.prepareStatement(sql);
            pStatement_ReservePlace.setInt(1,Integer.parseInt(chosenRow));
            pStatement_ReservePlace.setInt(2,Integer.parseInt(chosenPlace));
            pStatement_ReservePlace.setInt(3, sessionID);
            pStatement_ReservePlace.executeUpdate();
            ShowReservations(getCurrentFocus());
            TV_choice.setVisibility(View.INVISIBLE);
            button_yes.setVisibility(View.INVISIBLE);
            button_no.setVisibility(View.INVISIBLE);

            Toast toast = Toast.makeText(getApplicationContext(),"Deleted",Toast.LENGTH_SHORT);
            toast.show();
        }catch (SQLException e) {
            Toast toast = Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void NoCancel (View view) {
        TV_choice.setVisibility(View.INVISIBLE);
        button_yes.setVisibility(View.INVISIBLE);
        button_no.setVisibility(View.INVISIBLE);
    }
}