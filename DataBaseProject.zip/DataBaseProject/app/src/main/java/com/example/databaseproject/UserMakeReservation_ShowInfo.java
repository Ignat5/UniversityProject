package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class UserMakeReservation_ShowInfo extends AppCompatActivity {

    public static String EXTRA_USERID = "USERID";

    ListView LV_films;
    ListView LV_sessions;
    SimpleAdapter SA;
    GridView GV_Parking;
    public static List<Map<String,String>> dataListOfFilms;
    public static List<Map<String,String>> dataListOfSessions;
    public static List<Map<String,Object>> dataListOfParkingPlaces;

    String nameOfFilm = "";

    Integer sessionID = 0;
    Integer ParkingID = 0;
    Integer userID = 0;


    //Parking Places:
    EditText ET_row,ET_place;
    String chosenRow = "",chosenPlace = "";

    //Check
    Boolean isSessionChosen = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_make_reservation__show_info);

        userID = (Integer)getIntent().getExtras().get(EXTRA_USERID);

        LV_films = (ListView) findViewById(R.id.LV_UserMakeReservation_Films);
        LV_sessions = (ListView) findViewById(R.id.LV_UserMakeReservation_Sessions);

        GV_Parking = (GridView) findViewById(R.id.GV_ParkingPlaces);

        //Parking Places:
        ET_row = (EditText) findViewById(R.id.ET_ParkingPlace_Row);
        ET_place = (EditText) findViewById(R.id.ET_ParkingPlace_Place);

        LV_films.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Map<String,String> film = dataListOfFilms.get((int)id);
                nameOfFilm = film.get("NAME");

                ShowListOfSessionsOfChosenFilm(getCurrentFocus());
            }
        });

        LV_sessions.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    isSessionChosen = true;
                    Map<String,String> session = dataListOfSessions.get((int)id);
                    sessionID = Integer.parseInt(session.get("ID"));
                ShowParkingPlaces(getCurrentFocus());

                /*Intent intent = new Intent(UserMakeReservation_ShowInfo.this,UserMakeReservation_MakeReservation.class);
                intent.putExtra(UserMakeReservation_MakeReservation.EXTRA_USERID,EXTRA_USERID);
                intent.putExtra(UserMakeReservation_MakeReservation.EXTRA_SESSIONID,(int)id);
                startActivity(intent);*/
            }
        });

        ShowListOfFilms(getCurrentFocus());
        ShowListOfSessions(getCurrentFocus());
    }

    public void ShowListOfFilms(View view) {
        getData GD = new getData();
        dataListOfFilms = GD.getData_ListOfFilms();
        String[] fromwhere = {"NAME","GENRE","RATE","DURATION"};
        int[] viewwhere = {R.id.TV_templateFilms_nameOfFilm,R.id.TV_templateFilms_genreOfFilm,
                R.id.TV_templateFilms_rateOfFilm,R.id.TV_templateFilms_durationOfFilm};
        SA = new SimpleAdapter(UserMakeReservation_ShowInfo.this,dataListOfFilms,R.layout.tempate_films,fromwhere,viewwhere);
        LV_films.setAdapter(SA);
    }

    public void OrderByGenre (View view) {
        getData GD = new getData();
        dataListOfFilms = GD.getData_OrderedListOfFilms("genre");
        String[] fromwhere = {"NAME","GENRE","RATE","DURATION"};
        int[] viewwhere = {R.id.TV_templateFilms_nameOfFilm,R.id.TV_templateFilms_genreOfFilm,
                R.id.TV_templateFilms_rateOfFilm,R.id.TV_templateFilms_durationOfFilm};
        SA = new SimpleAdapter(UserMakeReservation_ShowInfo.this,dataListOfFilms,R.layout.tempate_films,fromwhere,viewwhere);
        LV_films.setAdapter(SA);
    }
    public void OrderByRate (View view) {
        getData GD = new getData();
        dataListOfFilms = GD.getData_OrderedListOfFilms("rate");
        String[] fromwhere = {"NAME","GENRE","RATE","DURATION"};
        int[] viewwhere = {R.id.TV_templateFilms_nameOfFilm,R.id.TV_templateFilms_genreOfFilm,
                R.id.TV_templateFilms_rateOfFilm,R.id.TV_templateFilms_durationOfFilm};
        SA = new SimpleAdapter(UserMakeReservation_ShowInfo.this,dataListOfFilms,R.layout.tempate_films,fromwhere,viewwhere);
        LV_films.setAdapter(SA);
    }
    public void OrderByDuration (View view) {
        getData GD = new getData();
        dataListOfFilms = GD.getData_OrderedListOfFilms("duration");
        String[] fromwhere = {"NAME","GENRE","RATE","DURATION"};
        int[] viewwhere = {R.id.TV_templateFilms_nameOfFilm,R.id.TV_templateFilms_genreOfFilm,
                R.id.TV_templateFilms_rateOfFilm,R.id.TV_templateFilms_durationOfFilm};
        SA = new SimpleAdapter(UserMakeReservation_ShowInfo.this,dataListOfFilms,R.layout.tempate_films,fromwhere,viewwhere);
        LV_films.setAdapter(SA);
    }

    public void ShowListOfSessions (View view) {
        getData GD = new getData();
        dataListOfSessions = GD.getData_ListOfSessions();
        String[] fromwhere = {"FILM_NAME","DATE","PRICE"};
        int[] viewwhere = {R.id.TV_templateSessions_film,R.id.TV_templateSessions_date, R.id.TV_templateSessions_price};
        SA = new SimpleAdapter(UserMakeReservation_ShowInfo.this,dataListOfSessions,R.layout.tempate_sessions,fromwhere,viewwhere);
        LV_sessions.setAdapter(SA);
    }
    public void ShowListOfSessionsOfChosenFilm (View view) {
        getData GD = new getData();
        dataListOfSessions = GD.getData_ListOfSessionsOfChosenFilm(nameOfFilm);
        String[] fromwhere = {"FILM_NAME","DATE","PRICE"};
        int[] viewwhere = {R.id.TV_templateSessions_film,R.id.TV_templateSessions_date, R.id.TV_templateSessions_price};
        SA = new SimpleAdapter(UserMakeReservation_ShowInfo.this,dataListOfSessions,R.layout.tempate_sessions,fromwhere,viewwhere);
        LV_sessions.setAdapter(SA);
    }
    public void ShowAllSessions (View view) {
        ShowListOfSessions(getCurrentFocus());
    }

    public void ShowParkingPlaces(View view) {
        getData GD = new getData();
        dataListOfParkingPlaces = GD.getData_ParkingPlaces(sessionID);
        String[] fromwhere = {"ROW","PLACE","ISRESERVED"};
        int[] viewwhere = {R.id.TV_templateParking_row,R.id.TV_templateParking_place,R.id.CheckBox_reserved};
        SA = new SimpleAdapter(UserMakeReservation_ShowInfo.this,dataListOfParkingPlaces,R.layout.tempate_parking,fromwhere,viewwhere);
        GV_Parking.setAdapter(SA);
    }

    public void ReserveTicket (View view) {
        if (isSessionChosen) {
            if (ET_place.getText().length() != 0 && ET_row.getText().length() != 0) {

                Map<String, Object> map = null;
                try {
                    chosenRow = ET_row.getText().toString();
                    chosenPlace = ET_place.getText().toString();
                } catch (Exception e) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Incorrect input", Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }

                for (int i = 0; i < dataListOfParkingPlaces.size(); i++) {
                    if (dataListOfParkingPlaces.get(i).get("ROW").toString().contentEquals(chosenRow) && dataListOfParkingPlaces.get(i).get("PLACE").toString().contentEquals(chosenPlace)) {
                        map = dataListOfParkingPlaces.get(i);
                    }
                }
                if ((Boolean) map.get("ISRESERVED")) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Chosen place is reserved", Toast.LENGTH_SHORT);
                    toast.show();
                    return;

                } else {
                    Connection connection = ConnectionHelper.getConnection();
                    try {
                        PreparedStatement pStatement = connection.prepareStatement("SELECT PP_id FROM ParkingPlace WHERE PP_sessionId=? AND (PP_place=? AND PP_row = ?)");
                        pStatement.setInt(1, sessionID);
                        pStatement.setInt(2, Integer.parseInt(chosenPlace));
                        pStatement.setInt(3, Integer.parseInt(chosenRow));
                        ResultSet rs = pStatement.executeQuery();
                        while (rs.next()) {
                            ParkingID = Integer.parseInt(rs.getString("PP_id"));
                        }

                        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO RESERVATIONS (reservation_userID,reservation_sessionID,reservation_parkingID)" +
                                "values(?,?,?) ");
                        preparedStatement.setInt(1, userID);
                        preparedStatement.setInt(2, sessionID);
                        preparedStatement.setInt(3, ParkingID);
                        preparedStatement.executeUpdate();

                        String sql = "UPDATE ParkingPlace SET PP_isReserved = 1 WHERE (PP_row=? AND PP_place = ?) AND PP_sessionId = ?";
                        PreparedStatement pStatement_ReservePlace = connection.prepareStatement(sql);
                        pStatement_ReservePlace.setInt(1, Integer.parseInt(chosenRow));
                        pStatement_ReservePlace.setInt(2, Integer.parseInt(chosenPlace));
                        pStatement_ReservePlace.setInt(3, sessionID);
                        pStatement_ReservePlace.executeUpdate();

                        Toast toast = Toast.makeText(getApplicationContext(), "Reserved", Toast.LENGTH_SHORT);
                        toast.show();

                        Intent intent = new Intent(UserMakeReservation_ShowInfo.this, UserMainPage.class);
                        intent.putExtra(UserMainPage.EXTRA_USERID, userID);
                        startActivity(intent);


                    } catch (SQLException e) {
                        Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT);
                        toast.show();
                    }
                }


            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Choose your parking place", Toast.LENGTH_SHORT);
                toast.show();
            }
       }else {
            Toast toast = Toast.makeText(getApplicationContext(),"Choose session", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

}