package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AdminMainPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main_page);
    }
    public void GoToFilms(View view) {
        Intent intent = new Intent(AdminMainPage.this,AdminActions_Films.class);
        startActivity(intent);
    }

    public void GoToSessions(View view) {
        Intent intent = new Intent(AdminMainPage.this,AdminActions_Sessions.class);
        startActivity(intent);
    }
    public void GoToUsers (View view) {
        Intent intent = new Intent(AdminMainPage.this,AdminActions_Users.class);
        startActivity(intent);
    }
}