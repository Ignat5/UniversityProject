package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class AdminActions_Films extends AppCompatActivity {


    public static List<Map<String,String>> dataListOfFilms;

    SimpleAdapter SA;
    ListView LV_films;
    Switch SW;
    Connection connection = ConnectionHelper.getConnection();

    //Add/Update Film
    Boolean isSwitchChecked = false;
    String film_Name,film_Genre;
    Integer film_Duration = 0;
    Double film_Rate = 0.0;

    EditText ET_filmName,ET_filmRate,ET_filmDuring;
    Spinner SP_genre;
    //DELETE Film
    EditText ET_filmNameDelete;
    String filmNameDelete;

    //обработка ошибок
    Integer mistakeCode = 0;

    //check
    Boolean isThereAFilm = false;
    Boolean isThereFilm_for_delete = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_actions__films);
        LV_films = (ListView) findViewById(R.id.LV_AdminActions_Films);
        SW = (Switch) findViewById(R.id.Switch);

        //ADD/UPDATE
        ET_filmName = (EditText) findViewById(R.id.ET_Admin_FilmsADD_name);
        ET_filmRate = (EditText) findViewById(R.id.ET_Admin_FilmsADD_rate);
        ET_filmDuring = (EditText) findViewById(R.id.ET_Admin_FilmsADD_during);
        SP_genre = (Spinner)  findViewById(R.id.Spinner_Admin_FilmsADD);
        //DELETE
        ET_filmNameDelete = (EditText) findViewById(R.id.ET_Admin_FilmsDelete);



        SW.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isSwitchChecked = isChecked;
                if(!isChecked) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Add Mode", Toast.LENGTH_SHORT);
                    toast.show();
                }else {
                    Toast toast = Toast.makeText(getApplicationContext(), "Update Mode", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

        ShowListOfFilms_Admin(getCurrentFocus());
    }

    public void ShowListOfFilms_Admin(View view) {
        getData GD = new getData();
        dataListOfFilms = GD.getData_ListOfFilms();
        String[] fromwhere = {"NAME","GENRE","RATE","DURATION"};
        int[] viewwhere = {R.id.TV_templateFilms_nameOfFilm,R.id.TV_templateFilms_genreOfFilm,
                R.id.TV_templateFilms_rateOfFilm,R.id.TV_templateFilms_durationOfFilm};
        SA = new SimpleAdapter(AdminActions_Films.this,dataListOfFilms,R.layout.tempate_films,fromwhere,viewwhere);
        LV_films.setAdapter(SA);
    }

    public void ChangeFilm(View view) {
        if(ET_filmName.getText().length()!=0 && ET_filmRate.getText().length()!=0 && ET_filmDuring.getText().length()!=0) {
            try {
                film_Name = ET_filmName.getText().toString();
                film_Genre = SP_genre.getSelectedItem().toString();
                film_Rate = Double.parseDouble(ET_filmRate.getText().toString());
                film_Duration = Integer.parseInt(ET_filmDuring.getText().toString());
            }catch (Exception e) {
                Toast toast = Toast.makeText(getApplicationContext(), "Incorrect input (type)", Toast.LENGTH_SHORT);
                toast.show();
                return;
            }
                //
            if (!isSwitchChecked) {
                try {
                    String sql = "INSERT INTO FILMS (film_name,film_genre,film_rate,film_duration) values (?,?,?,?)";
                    PreparedStatement pStatement = connection.prepareStatement(sql);
                    pStatement.setString(1, film_Name);
                    pStatement.setString(2, film_Genre);
                    pStatement.setDouble(3, film_Rate);
                    pStatement.setInt(4, film_Duration);
                    pStatement.executeUpdate();
                    Toast toast = Toast.makeText(getApplicationContext(), "Added", Toast.LENGTH_SHORT);
                    toast.show();
                } catch (SQLException e) {
                    mistakeCode = e.getErrorCode();
                    if(mistakeCode==547) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Incorrect input", Toast.LENGTH_SHORT);
                        toast.show();
                    }
                    Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }

            } else {
                isThereAFilm = false;

                for (int i = 0; i < dataListOfFilms.size(); i++) {
                    if (film_Name.contentEquals(dataListOfFilms.get(i).get("NAME"))) {
                        isThereAFilm = true;
                        /*Toast toast = Toast.makeText(getApplicationContext(), "yes", Toast.LENGTH_LONG);
                        toast.show();*/
                    }
                }

                if (isThereAFilm) {
                    try {
                        String sql = "UPDATE FILMS SET film_genre = ?,film_rate = ?,film_duration = ? WHERE film_name=?";
                        PreparedStatement pStatement = connection.prepareStatement(sql);
                        pStatement.setString(1, film_Genre);
                        pStatement.setDouble(2, film_Rate);
                        pStatement.setInt(3, film_Duration);
                        pStatement.setString(4, film_Name);
                        pStatement.executeUpdate();
                    Toast toast = Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_SHORT);
                    toast.show();
                    } catch (SQLException e) {
                        mistakeCode = e.getErrorCode();
                        if (mistakeCode == 547) {
                            Toast toast = Toast.makeText(getApplicationContext(), "Incorrect input", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT);
                        toast.show();
                    }
            } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "There is no film with this name", Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }


            }
        }else {
            Toast toast = Toast.makeText(getApplicationContext(), "Fill 'Add/Update' Fields", Toast.LENGTH_SHORT);
            toast.show();
        }
        ShowListOfFilms_Admin(getCurrentFocus());
    }

    public void DeleteFilm (View view) {
    if(ET_filmNameDelete.getText().length()!=0) {
        filmNameDelete = ET_filmNameDelete.getText().toString();

        isThereFilm_for_delete = false;

        for (int i = 0; i < dataListOfFilms.size(); i++) {
            if (filmNameDelete.contentEquals(dataListOfFilms.get(i).get("NAME"))) {
                isThereFilm_for_delete = true;
            }
        }

        if (isThereFilm_for_delete) {
            try {
                String sql = "DELETE FILMS WHERE film_name=?";
                PreparedStatement pStatement = connection.prepareStatement(sql);
                pStatement.setString(1, filmNameDelete);
                pStatement.executeUpdate();
                ShowListOfFilms_Admin(getCurrentFocus());
                Toast toast = Toast.makeText(getApplicationContext(), "Deleted", Toast.LENGTH_SHORT);
                toast.show();
            } catch (SQLException e) {
                Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT);
                toast.show();
            }
    } else {
            Toast toast = Toast.makeText(getApplicationContext(), "There is no film with this name", Toast.LENGTH_SHORT);
            toast.show();
            return;
        }

    }else {
        Toast toast = Toast.makeText(getApplicationContext(), "Fill 'Delete' Field", Toast.LENGTH_SHORT);
        toast.show();
    }

    }
}