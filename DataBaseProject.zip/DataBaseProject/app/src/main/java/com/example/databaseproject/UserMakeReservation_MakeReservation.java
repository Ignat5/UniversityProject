package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserMakeReservation_MakeReservation extends AppCompatActivity {

    public static String EXTRA_USERID = "USERID";
    public static String EXTRA_SESSIONID = "SESSIONID";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_make_reservation__make_reservation);
    }
}