package com.example.databaseproject;

import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class getData {

    Connection connection = null;

    public List<Map<String,String>> getData_ListOfFilms() {
        List<Map<String,String>> data = new ArrayList<Map<String,String>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {
                String query = "SELECT * FROM view_allFilms";
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery(query);
                while (rs.next()) {
                    Map<String,String> dataOfRow = new HashMap<String,String>();
                    dataOfRow.put("NAME",rs.getString("film_name"));
                    dataOfRow.put("GENRE",rs.getString("film_genre"));
                    dataOfRow.put("RATE",rs.getString("film_rate"));
                    dataOfRow.put("DURATION",rs.getString("film_duration"));
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (Exception e) {

        }
        return data;
    }

    public List<Map<String,String>> getData_OrderedListOfFilms (String orderBy) {
        List<Map<String,String>> data = new ArrayList<Map<String,String>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {
                PreparedStatement pStatement = connection.prepareStatement("SELECT * FROM SortFilms (?)");
                pStatement.setString(1,orderBy);
                ResultSet rs = pStatement.executeQuery();

                while (rs.next()) {
                    Map<String,String> dataOfRow = new HashMap<String,String>();
                    dataOfRow.put("NAME",rs.getString("film_name"));
                    dataOfRow.put("GENRE",rs.getString("film_genre"));
                    dataOfRow.put("RATE",rs.getString("film_rate"));
                    dataOfRow.put("DURATION",rs.getString("film_duration"));
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (Exception e) {

        }
        return data;
    }

    public List<Map<String,String>> getData_ListOfSessions() {
        List<Map<String,String>> data = new ArrayList<Map<String,String>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {
                String query = "SELECT * FROM view_allSessions";
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery(query);
                while (rs.next()) {
                    Map<String,String> dataOfRow = new HashMap<String,String>();
                    dataOfRow.put("FILM_NAME",rs.getString("session_filmName"));
                    dataOfRow.put("DATE",rs.getString("session_date"));
                    dataOfRow.put("PRICE",rs.getString("session_price"));
                    dataOfRow.put("ID",rs.getString("session_id"));
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (Exception e) {

        }
        return data;
    }

    public List<Map<String,String>> getData_ListOfSessionsOfChosenFilm(String filmName) {
        List<Map<String,String>> data = new ArrayList<Map<String,String>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {
                PreparedStatement pStatement = connection.prepareStatement
                        ("SELECT session_filmName,convert(varchar,session_date,100) AS session_date,session_price,session_id FROM FILMS_SESSIONS WHERE session_filmName=?  ORDER BY session_date");
                pStatement.setString(1,filmName);
                ResultSet rs = pStatement.executeQuery();
                while (rs.next()) {
                    Map<String,String> dataOfRow = new HashMap<String,String>();
                    dataOfRow.put("FILM_NAME",rs.getString("session_filmName"));
                    dataOfRow.put("DATE",rs.getString("session_date"));
                    dataOfRow.put("PRICE",rs.getString("session_price"));
                    dataOfRow.put("ID",rs.getString("session_id"));
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (SQLException e) {
            e.getMessage();
        }
        return data;
    }


    public List<Map<String,Object>> getData_ParkingPlaces(Integer sessionID) {
        List<Map<String,Object>> data = new ArrayList<Map<String,Object>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {

                PreparedStatement pStatement = connection.prepareStatement("SELECT * FROM ParkingPlace WHERE PP_sessionId=?");
                pStatement.setInt(1,sessionID);
                ResultSet rs = pStatement.executeQuery();
                while (rs.next()) {
                    Map<String,Object> dataOfRow = new HashMap<String,Object>();
                    dataOfRow.put("ROW",rs.getString("PP_row"));
                    dataOfRow.put("PLACE",rs.getString("PP_place"));
                    if(rs.getString("PP_isReserved") == "1"){dataOfRow.put("ISRESERVED",true);}else
                    {dataOfRow.put("ISRESERVED",false);}
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (Exception e) {

        }
        return data;
    }

    public List<Map<String,String>> getData_Reservations (Integer userID) {
        List<Map<String,String>> data = new ArrayList<Map<String,String>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {
                PreparedStatement pStatement = connection.prepareStatement("SELECT * FROM view_Reservations WHERE reservation_userID = ?");
                pStatement.setInt(1,userID);
                ResultSet rs = pStatement.executeQuery();

                while (rs.next()) {
                    Map<String,String> dataOfRow = new HashMap<String,String>();
                    dataOfRow.put("USERNAME",rs.getString("userName"));
                    dataOfRow.put("FILMNAME",rs.getString("session_filmName"));
                    dataOfRow.put("DATE",rs.getString("session_date"));
                    dataOfRow.put("PRICE",rs.getString("session_price"));
                    dataOfRow.put("ROW",rs.getString("PP_row"));
                    dataOfRow.put("PLACE",rs.getString("PP_place"));
                    dataOfRow.put("RESERVATION_ID",rs.getString("reservation_id"));
                    dataOfRow.put("SESSION_ID",rs.getString("session_id"));
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (Exception e) {

        }
        return data;
    }


    public List<Map<String,String>> getData_Users () {
        List<Map<String,String>> data = new ArrayList<Map<String,String>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {
                String query = "SELECT userID,userName,userPhone FROM Users WHERE userName!='admin'";
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery(query);
                while (rs.next()) {
                    Map<String,String> dataOfRow = new HashMap<String,String>();
                    dataOfRow.put("USER_ID",rs.getString("userID"));
                    dataOfRow.put("USER_NAME",rs.getString("userName"));
                    dataOfRow.put("USER_PHONE",rs.getString("userPhone"));
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (Exception e) {

        }
        return data;
    }

    public List<Map<String,String>> getData_ChosenUser (String userPhone) {
        List<Map<String,String>> data = new ArrayList<Map<String,String>>();
        try {
            connection = ConnectionHelper.getConnection();
            if(connection == null) {

            }else {
                String query = "SELECT * FROM Users WHERE userPhone = ?";
                PreparedStatement pStatement = connection.prepareStatement(query);
                pStatement.setString(1,userPhone);
                ResultSet rs = pStatement.executeQuery();
                while (rs.next()) {
                    Map<String,String> dataOfRow = new HashMap<String,String>();
                    dataOfRow.put("USER_ID",rs.getString("userID"));
                    dataOfRow.put("USER_NAME",rs.getString("userName"));
                    dataOfRow.put("USER_PHONE",rs.getString("userPhone"));
                    data.add(dataOfRow);
                }
                connection.close();
            }
        }catch (Exception e) {

        }
        return data;
    }

}
