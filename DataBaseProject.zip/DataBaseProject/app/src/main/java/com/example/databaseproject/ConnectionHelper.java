package com.example.databaseproject;

import android.os.StrictMode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionHelper {
    private static String ip = "192.168.0.24";
    private static String port = "1433";
    private static String _class = "net.sourceforge.jtds.jdbc.Driver";
    private static String database = "testDB";
    private static String username = "user";
    private  static String password = "password";
    private static String url = "jdbc:jtds:sqlserver://" + ip +":"+ port +"/"+database;
    private static Connection connection = null;

    public static Connection getConnection() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            Class.forName(_class);
            connection = DriverManager.getConnection(url,username,password);
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
