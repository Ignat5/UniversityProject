package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class UserRegistration extends AppCompatActivity {

Connection connection = null;

EditText ET_userName,ET_userPassword,ET_userPhone;
String userName_add = "",userPassword_add = "",userPhone_add = "";
Integer mistakeCode_uniqueUser = 2627;
Integer mistakeCode_phoneNumber = 547;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);
        connection = ConnectionHelper.getConnection();

        ET_userName = (EditText) findViewById(R.id.ET_UserRegistration_userName);
        ET_userPassword = (EditText) findViewById(R.id.ET_UserRegistration_userPassword);
        ET_userPhone = (EditText) findViewById(R.id.ET_UserRegistration_userPhone);
    }

    public void RegisterUser (View view) {
        if (ET_userName.getText().length() <= 20 && ET_userPassword.getText().length() <= 20) {
            if (ET_userPhone.getText().length() != 0 && ET_userPassword.getText().length() != 0 && ET_userPhone.getText().length() != 0) {
                userName_add = ET_userName.getText().toString();
                userPassword_add = ET_userPassword.getText().toString();
                userPhone_add = ET_userPhone.getText().toString();
                try {
                    String sql1 = "call AddUser(?,?,?)";
                    CallableStatement cStatement_isThereUser = connection.prepareCall(sql1);
                    cStatement_isThereUser.setString(1, userName_add);
                    cStatement_isThereUser.setString(2, userPassword_add);
                    cStatement_isThereUser.setString(3, userPhone_add);
                    cStatement_isThereUser.execute();
                    Toast toast = Toast.makeText(getApplicationContext(), "OK", Toast.LENGTH_SHORT);
                    toast.show();
                    Intent intent = new Intent(UserRegistration.this, MainActivity.class);
                    startActivity(intent);

                } catch (SQLException e) {
                    String mistake = e.getSQLState();
                    String mistake1 = e.getMessage();
                    Integer mistake2 = e.getErrorCode();
                    if (mistakeCode_uniqueUser == e.getErrorCode()) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Those name or phone are already registered", Toast.LENGTH_SHORT);
                        toast.show();
                        return;
                    }
                    if (mistakeCode_phoneNumber == e.getErrorCode()) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Incorrect input of phone number Template:'8(7) *** *** ** **'", Toast.LENGTH_LONG);
                        toast.show();
                        return;
                    }
                /*Toast toast = Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT);
                toast.show();*/
                }
            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Enter required data", Toast.LENGTH_SHORT);
                toast.show();
                return;
            }
       }else {
            Toast toast = Toast.makeText(getApplicationContext(), "Not more then 20 signs", Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
    }
}