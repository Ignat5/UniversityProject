package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class MainActivity extends AppCompatActivity {

    Connection connection = null;

    EditText ET_userName,ET_userPassword;
    String userName = "",userPassword="";

    int isThereUser = 0;
    int isAdmin = 0;
    int userId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get connection to the DB
        connection = ConnectionHelper.getConnection();
        if(connection!=null) {
            Toast toast = Toast.makeText(getApplicationContext(),"Connection is ok",Toast.LENGTH_SHORT);
            toast.show();
        }
        //get id's of EditTexts
        ET_userName = (EditText) findViewById(R.id.ET_MainActivity_UserName);
        ET_userPassword = (EditText) findViewById(R.id.ET_MainActivity_UserPassword);
    }

    public void Login (View view) {
        if(ET_userName.getText().length()!=0 && ET_userPassword.getText().length()!=0) {
            userName = ET_userName.getText().toString();
            userPassword = ET_userPassword.getText().toString();

            try {
                String sql1 = "call IsUserExists(?,?,?)";
                CallableStatement cStatement_isThereUser = connection.prepareCall(sql1);
                cStatement_isThereUser.setString(1,userName);
                cStatement_isThereUser.setString(2,userPassword);
                cStatement_isThereUser.registerOutParameter(3, Types.INTEGER);
                cStatement_isThereUser.execute();
                cStatement_isThereUser.getMoreResults();
                isThereUser = cStatement_isThereUser.getInt(3);

                if(isThereUser == 1) {
                    /*Toast toast = Toast.makeText(getApplicationContext(),"1",Toast.LENGTH_SHORT);
                    toast.show();*/
                    //Действия при условии, что такой пользователь есть в базе
                    String sql2 = "call IsUserAdmin(?,?,?)";
                    CallableStatement cStatement_isAdmin = connection.prepareCall(sql2);
                    cStatement_isAdmin.setString(1,userName);
                    cStatement_isAdmin.setString(2,userPassword);
                    cStatement_isAdmin.registerOutParameter(3,Types.INTEGER);
                    cStatement_isAdmin.execute();
                    cStatement_isAdmin.getMoreResults();
                    isAdmin = cStatement_isAdmin.getInt(3);

                    if(isAdmin == 1) { //Действия при условии, что пользователь - админ
                        Intent intentAdmin = new Intent(MainActivity.this,AdminMainPage.class);
                        startActivity(intentAdmin);
                    }
                    else { // Действия при условии, что пользователь - клиент
                        //1. Поучим id пользователя
                        String sql3 = "call getUserId (?,?)";
                        CallableStatement cStatement_getId = connection.prepareCall(sql3);
                        cStatement_getId.setString(1,userName);
                        cStatement_getId.registerOutParameter(2,Types.INTEGER);
                        cStatement_getId.execute();
                        cStatement_getId.getMoreResults();
                        userId = cStatement_getId.getInt(2);

                        Intent intentUser = new Intent(MainActivity.this,UserMainPage.class);
                        intentUser.putExtra(UserMainPage.EXTRA_USERID,userId);
                        startActivity(intentUser);
                    }


                }
                if(isThereUser == 0) {
                    Toast toast = Toast.makeText(getApplicationContext(),"Check your input",Toast.LENGTH_SHORT);
                    toast.show();
                    //Действия при условии, что пользователя нет в базе
                }
            }catch (SQLException e) {
                Toast toast = Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG);
                toast.show();
            }
        }else {
            Toast toast = Toast.makeText(getApplicationContext(),"Enter all data",Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void GoToRegistrationPage (View view) {
        Intent intent = new Intent(MainActivity.this,UserRegistration.class);
        startActivity(intent);
    }

}