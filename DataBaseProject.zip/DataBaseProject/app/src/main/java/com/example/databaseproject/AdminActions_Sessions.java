package com.example.databaseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AdminActions_Sessions extends AppCompatActivity {

    public static List<Map<String,String>> dataListOfSessions;
    public static List<Map<String,String>> dataListOfFilms;
    SimpleAdapter SA;
    ListView LV_sessions;

    Spinner SP_sessions;
    Switch SV_sessions;

    EditText ET_id,ET_date,ET_price;

    Timestamp session_date;
    Integer session_price = 0,session_id = 0;
    String session_filmName = "";

    Connection connection = ConnectionHelper.getConnection();

    Integer mistakeCode = 0;
    Boolean isSwitchChecked = false;

    //Delete
    EditText ET_id_delete;
    Integer session_id_delete;
    //count of places
    Integer session_id_count = 0;
    Integer countOfReservedPlaces = 0;
    Integer TotalIncome = 0;
    TextView TV_Count;
    TextView TV_TotalIncome;

    //check
    Boolean isThereID_update = false;
    Boolean isThereID_delete = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_actions__sessions);

        LV_sessions = (ListView) findViewById(R.id.LV_AdminActions_Sessions);
        SP_sessions = (Spinner) findViewById(R.id.Spinner_Admin_SessionsAdd);
        SV_sessions = (Switch) findViewById(R.id.Switch_Sessions);

        ET_id = (EditText) findViewById(R.id.ET_Admin_SessionsUpdate_ID);
        ET_date = (EditText) findViewById(R.id.ET_Admin_SessionsAdd_date);
        ET_price = (EditText) findViewById(R.id.ET_Admin_SessionsAdd_price);
        //delete
        ET_id_delete = (EditText) findViewById(R.id.ET_Admin_SessionDeleteID);
        //Count
        TV_Count = (TextView) findViewById(R.id.TV_AdminActions_CountOfReservedPlaces);
        TV_TotalIncome = (TextView) findViewById(R.id.TV_AdminActions_TotalIncome);
        LV_sessions.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Map<String,String> session = dataListOfSessions.get((int)id);
                session_id_count = Integer.parseInt(session.get("ID"));
                ShowCountOfReservedPlaces(getCurrentFocus());
                ShowTotalIncome(getCurrentFocus());
            }
        });

        SV_sessions.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isSwitchChecked = isChecked;
                if(isChecked) {
                    ET_id.setVisibility(View.VISIBLE);
                }else {
                    ET_id.setVisibility(View.INVISIBLE);
                }
            }
        });



        //сохранение названий фильмов
        {
            getData GD = new getData();
            dataListOfFilms = GD.getData_ListOfFilms();
            List<String> dataListOfFilmsNames = new ArrayList<>();
            for (int i = 0; i < dataListOfFilms.size(); i++) {
                dataListOfFilmsNames.add(dataListOfFilms.get(i).get("NAME"));
            }
            ArrayAdapter<?> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, dataListOfFilmsNames);
            adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
            SP_sessions.setAdapter(adapter);
        }
        //

        ShowListOfSessions_Admin(getCurrentFocus());
    }

    public void ShowListOfSessions_Admin (View view) {
        getData GD = new getData();
        dataListOfSessions = GD.getData_ListOfSessions();
        String[] fromwhere = {"FILM_NAME","DATE","PRICE","ID"};
        int[] viewwhere = {R.id.TV_templateSessions_film_admin,R.id.TV_templateSessions_date_admin, R.id.TV_templateSessions_price_admin,R.id.TV_templateSessions_id_admin};
        SA = new SimpleAdapter(AdminActions_Sessions.this,dataListOfSessions,R.layout.template_sessions_admin,fromwhere,viewwhere);
        LV_sessions.setAdapter(SA);
    }

        public void AddSession (View view) {
        if (!isSwitchChecked) {
            if (ET_date.getText().length() != 0 && ET_price.getText().length() != 0) {
                try {
                    String date = AddPart(ET_date.getText().toString());
                    session_date = Timestamp.valueOf(date);
                    session_price = Integer.parseInt(ET_price.getText().toString());
                    session_filmName = SP_sessions.getSelectedItem().toString();
                } catch (Exception e) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Incorrect type(check template for date: YYYY-MM-DD HH:MM)", Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }
                try {
                    String sql = "INSERT INTO FILMS_SESSIONS (session_filmName,session_date,session_price) values (?,?,?)";
                    PreparedStatement pStatement = connection.prepareStatement(sql);
                    pStatement.setString(1, session_filmName);
                    pStatement.setTimestamp(2, session_date);
                    pStatement.setInt(3, session_price);
                    pStatement.executeUpdate();
                    Toast toast = Toast.makeText(getApplicationContext(), "Added", Toast.LENGTH_SHORT);
                    toast.show();
                } catch (SQLException e) {
                    mistakeCode = e.getErrorCode();
                    if (mistakeCode == 547) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Incorrect input (price)", Toast.LENGTH_SHORT);
                        toast.show();
                    }
                    Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }

            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Fill fields 'Add'", Toast.LENGTH_SHORT);
                toast.show();
                return;
            }
            ShowListOfSessions_Admin(getCurrentFocus());
        }
        else { //UPDATE

            if (ET_date.getText().length() != 0 && ET_price.getText().length() != 0 && ET_id.getText().length()!=0) {
                try {
                    String date = AddPart(ET_date.getText().toString());
                    session_date = Timestamp.valueOf(date);
                    session_price = Integer.parseInt(ET_price.getText().toString());
                    session_filmName = SP_sessions.getSelectedItem().toString();
                    session_id = Integer.parseInt(ET_id.getText().toString());

                } catch (Exception e) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Incorrect type(check template for date: YYYY-MM-DD HH:MM)", Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }

                isThereID_update = false;
                for (int i = 0; i < dataListOfSessions.size(); i++) {
                    if (session_id == Integer.parseInt(dataListOfSessions.get(i).get("ID"))) {
                        isThereID_update = true;
                    }
                }

                if (isThereID_update) {
                    try {
                        String sql = "UPDATE FILMS_SESSIONS SET session_filmName=?,session_date=?,session_price=? WHERE session_id=?";
                        PreparedStatement pStatement = connection.prepareStatement(sql);
                        pStatement.setString(1, session_filmName);
                        pStatement.setTimestamp(2, session_date);
                        pStatement.setInt(3, session_price);
                        pStatement.setInt(4, session_id);
                        pStatement.executeUpdate();
                        Toast toast = Toast.makeText(getApplicationContext(), "Update", Toast.LENGTH_SHORT);
                        toast.show();
                    } catch (SQLException e) {
                        mistakeCode = e.getErrorCode();
                        if (mistakeCode == 547) {
                            Toast toast = Toast.makeText(getApplicationContext(), "Incorrect update (price)", Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT);
                        toast.show();
                        return;
                    }
            }else {
                    Toast toast = Toast.makeText(getApplicationContext(),"There is no session with this id", Toast.LENGTH_SHORT);
                    toast.show();
                }

            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Fill fields 'Update'", Toast.LENGTH_SHORT);
                toast.show();
                return;
            }
            ShowListOfSessions_Admin(getCurrentFocus());
        }

        }

        public String AddPart(String date) {
            return (date + ":00");
        }

        public void DeleteSession (View view) {
            if(ET_id_delete.getText().length()!=0) {
                session_id_delete = Integer.parseInt(ET_id_delete.getText().toString());

                isThereID_delete = false;
                for (int i = 0; i < dataListOfSessions.size(); i++) {
                    if (session_id_delete == Integer.parseInt(dataListOfSessions.get(i).get("ID"))) {
                        isThereID_delete = true;
                    }
                }

                if (isThereID_delete) {

                    try {
                        String sql = "DELETE FILMS_SESSIONS WHERE session_id=?";
                        PreparedStatement pStatement = connection.prepareStatement(sql);
                        pStatement.setInt(1, session_id_delete);
                        pStatement.executeUpdate();
                        ShowListOfSessions_Admin(getCurrentFocus());
                        Toast toast = Toast.makeText(getApplicationContext(), "Deleted", Toast.LENGTH_SHORT);
                        toast.show();
                    } catch (SQLException e) {
                        Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT);
                        toast.show();
                    }
            }else {
                    Toast toast = Toast.makeText(getApplicationContext(), "There is no session with this id", Toast.LENGTH_SHORT);
                    toast.show();
                }

            }else {
                Toast toast = Toast.makeText(getApplicationContext(), "Fill 'Delete' Field", Toast.LENGTH_SHORT);
                toast.show();
            }
        }

        public void ShowCountOfReservedPlaces(View view) {
            try {
                String sql1 = "call CountReservedPlaces(?,?)";
                CallableStatement cStatement = connection.prepareCall(sql1);
                cStatement.setInt(1, session_id_count);
                cStatement.registerOutParameter(2, Types.INTEGER);
                cStatement.execute();
                cStatement.getMoreResults();
                countOfReservedPlaces = cStatement.getInt(2);
                TV_Count.setText("Count of reserved places:"+String.valueOf(countOfReservedPlaces)+"/16");
            }catch (SQLException e) {
                Toast toast = Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG);
                toast.show();
            }
        }

        public void ShowTotalIncome (View view) {
            try {
                String sql1 = "call TotalIncome(?,?)";
                CallableStatement cStatement = connection.prepareCall(sql1);
                cStatement.setInt(1, session_id_count);
                cStatement.registerOutParameter(2, Types.INTEGER);
                cStatement.execute();
                cStatement.getMoreResults();
                TotalIncome = cStatement.getInt(2);
                TV_TotalIncome.setText("Total income:"+String.valueOf(TotalIncome)+" RUB");
            }catch (SQLException e) {
                Toast toast = Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG);
                toast.show();
            }
        }
}